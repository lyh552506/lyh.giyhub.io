# 有关GitHub

## 1.注册

![](https://s1.ax1x.com/2022/09/08/vqNdED.png)

## 2.创建本地化git库

![](https://s1.ax1x.com/2022/09/08/vqNHK0.png)

#### ***##&&***存储库名称须保持为：___.github.io

![](https://s1.ax1x.com/2022/09/08/vqUZPH.png)

## 3.上传/添加文件---commit message

![](https://s1.ax1x.com/2022/09/08/vqUKMt.png)

点击创建新文件进行文件的创建

上传文件进行添加文件

## 4.主页地址

https://github.com/lyh552506/lyh.giyhub.io

## 5.尝试创立博客（半成功品？？）

上传文件成功后，点击settings（设置）

![](https://s1.ax1x.com/2022/09/08/vqaZwT.png)

此时会看到自己的博客网址

![](https://s1.ax1x.com/2022/09/08/vqagAS.png)

此时由于我的网址没有上传网页文件，点开该网址并不会出现我的博客，于是我回到主界面上传文件（本人新手小白并不会编辑网站博客的代码呜呜呜），于是我拥有了一个我的博客简易版(尽我所能啦)

![](https://s1.ax1x.com/2022/09/08/vqdiND.png)

博客网址：https://lyh552506.github.io/lyh.giyhub.io/