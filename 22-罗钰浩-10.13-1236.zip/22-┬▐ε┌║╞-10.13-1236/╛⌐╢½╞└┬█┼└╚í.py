import requests
import json



class Jdcomment_spider(object):

    def __init__(self, file_name='jingdong_pinglun'):
       self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36 Edg/106.0.1370.42'
        }

       #打开一个文件
       self.fp = open(f'./{file_name}.txt','w',encoding='utf-8')
       print(f'爬虫开始，打开{file_name}文件')

    def parse_one_page(self,url):
        #发起请求
        response = requests.get(url,headers=self.headers)
        #将json格式字符串转换成字典
        js_data = response.json()
        #提取数据
        comment_list =js_data['comments']

        for comment in comment_list:
            #购买用户的昵称
            nickname =comment.get('nickname')
            #商品的id
            goods_id = comment.get('id')
            #评分

            score = comment.get('score')
            #评论时间
            creationTime = comment.get('creationTime')
            #评价内容
            content = comment.get('content')
            content = content.replace('\n',' ')

            print(content)

            #数据的存储
            self.fp.write(f'{nickname}\t{goods_id}\t{score}\t{creationTime}\t{content}\t\n')






    def parse_max_page(self):

        for page_num in range(101):
            print(f'正在抓取{ page_num}页的数据')

            #生成一个url
            url=f'https://club.jd.com/comment/productPageComments.action?callback=fetchJSON_comment98&productId=100019125569&score=0&sortType=5&page={page_num}&pageSize=10&isShadowSku=0&rid=0&fold=1'

            #调用函数
            self.parse_one_page(url=url)


    def close_files(self):
        self.fp.close()
        print('爬虫结束，关闭文件')


if __name__=='__main__':

    jd_spider= Jdcomment_spider()

    jd_spider.parse_max_page()

    jd_spider.close_files()

    















